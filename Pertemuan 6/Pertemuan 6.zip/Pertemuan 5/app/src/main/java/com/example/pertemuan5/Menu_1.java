package com.example.pertemuan5;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Menu_1 extends AppCompatActivity {
//Deklarasi object java
    Button Btn2; //membuat variabel baru
    Button Btn3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.menu_1);

    //hubungan object java dengan ID XML
        Btn2 = findViewById(R.id.btn1);
        Btn3 = findViewById(R.id.btn2);
    }

    //code merubah warna
    public void Rubah_Warna(View v){
        Btn2.setBackgroundColor(Color.RED);
    }
    public void Rubah_Warna_Hijau(View v) {
        Btn3.setBackgroundColor(Color.GREEN);
    }
}
