package com.example.pertemuan5;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Menu_3 extends AppCompatActivity {

    Button Button1;
    EditText TextNama;
    TextView Hasil;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.menu_3);

        // Panggil object berdasrkan ID
        TextNama = findViewById(R.id.Text_nama);
        Hasil = findViewById(R.id.Lbl_Hasil);
        Button1 = findViewById(R.id.btn1);
    }

    public void Tampil_Hasil(View view) {
        Hasil.setText("Hasilnya Adalah : "+TextNama.getText());
    }
}
