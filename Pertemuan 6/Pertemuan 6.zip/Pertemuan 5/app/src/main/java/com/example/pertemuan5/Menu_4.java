package com.example.pertemuan5;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Menu_4 extends AppCompatActivity {

    Button Button2;
    EditText Textangka;
    TextView Hasil;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.menu_4);

        Textangka = findViewById(R.id.Text_edit);
        Hasil = findViewById(R.id.Hasil_angka);
        Button2 = findViewById(R.id.btn1);
    }

    public void getHasil(View view){
        String input = Textangka.getText().toString();

        int x = 1;
        int y = 1;
        int hasil = Integer.parseInt(input);

        while (y != hasil){
            x = x + 1;
            y = x * x;
        }
        Hasil.setText("Hasil Dari Akar "+hasil+" Adalah "+x);
    }
}
