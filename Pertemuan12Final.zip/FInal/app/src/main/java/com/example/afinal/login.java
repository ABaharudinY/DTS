package com.example.afinal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class login extends AppCompatActivity {

    EditText Edname, Edpass;
    Button Blogin, Bkeluar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        Edname = findViewById(R.id.idnama);
        Edpass = findViewById(R.id.idpassword);
        Blogin = findViewById(R.id.idlogin);
        Bkeluar = findViewById(R.id.idkeluar);
    }

    public void setBkeluar(View view){

        finish();
    }

    public void setBlogin(View view){
        String user = Edname.getText().toString();
        String pass = Edpass.getText().toString();

        if (user.equals("Admin") && pass.equals("Admin")){
           startActivity(new Intent(this, MainActivity.class));
            finish();
            Toast.makeText(this,"Login Berhasil ",Toast.LENGTH_SHORT).show();
        }else {
            Toast.makeText(this,"Username dan Password Salah ",Toast.LENGTH_SHORT).show();
        }
    }
}
