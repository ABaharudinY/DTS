package com.example.afinal;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.afinal.DbHelper.DbHelper;

public class EditData extends AppCompatActivity {

    EditText te_id, tename, teaddress;
    Button cancel, submit;
    DbHelper SQLite = new DbHelper(this);
    String id, name, address;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_data);
        te_id = findViewById(R.id.txt_id);
        tename = findViewById(R.id.id_name);
        teaddress = findViewById(R.id.id_address);
        cancel = findViewById(R.id.id_cancel);
        submit = findViewById(R.id.id_submit);

        id = getIntent().getStringExtra(MainActivity.TAG_ID);
        name = getIntent().getStringExtra(MainActivity.TAG_NAME);
        address = getIntent().getStringExtra(MainActivity.TAG_ADDRESS);


        if (id == null || id == "") {
            setTitle("Add Data");
        } else {
            setTitle("Edit Data");
            te_id.setText(id);
            tename.setText(name);
            teaddress.setText(address);
        }

    }

    public void submit(View v) {
        try {
            if (te_id.getText().toString().equals("")) {
                save();
            } else {
                edit();
            }
        } catch (Exception e) {
            Log.e("submit", e.toString());
        }
    }

    public void cancel(View v){
        blank();
        finish();
    }

    @Override
    public void onBackPressed(){
        finish();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        switch (item.getItemId()){
            case android.R.id.home:
                blank();
                this.finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);

        }
    }

    private void blank(){
        tename.requestFocus();
        te_id.setText(null);
        tename.setText(null);
        teaddress.setText(null);
    }

    private void save(){
        if (String.valueOf(tename.getText()).equals(null) || String.valueOf(tename.getText()).equals("") ||
                String.valueOf(teaddress.getText()).equals(null) || String.valueOf(teaddress.getText()).equals("")){
            Toast.makeText(getApplicationContext(),
                    "Please input name or address ...", Toast.LENGTH_SHORT).show();
        }else {
            SQLite.insert(tename.getText().toString().trim(), teaddress.getText().toString().trim());
            blank();
            finish();
        }

    }
    private void edit(){
        if (String.valueOf(tename.getText()).equals(null) || String.valueOf(tename.getText()).equals("") ||
                String.valueOf(teaddress.getText()).equals(null) || String.valueOf(teaddress.getText()).equals("")) {
            Toast.makeText(getApplicationContext(),
                    "Please input name or address ....", Toast.LENGTH_SHORT).show();
        }else {
            SQLite.update(Integer.parseInt(te_id.getText().toString().trim()),tename.getText().toString().trim(),
                   teaddress.getText().toString().trim());
            blank();
            finish();
        }
    }
}
