package com.example.androidapi;

import static org.junit.Assert.*;

public class MainActivityTest {

}